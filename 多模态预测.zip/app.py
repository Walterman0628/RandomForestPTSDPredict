from flask import Flask, request, render_template, jsonify
import os
import pandas as pd
import numpy as np
from scipy.stats import skew, kurtosis
from joblib import load

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'

# 定义连续变量的最小值和最大值
min_max_values = {
    'ASD_Dissociation': (5, 25),
    'ASD_Reexperience': (5, 25),
    'ASD_Avoidance': (4, 20),
    'ASD_Hypervigilance': (5, 25),
    'resilience': (10, 50)
}

def normalize(value, min_val, max_val):
    return (value - min_val) / (max_val - min_val)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    # 获取问卷数据
    disaster = request.form['disaster']
    ASD_Dissociation = normalize(float(request.form['ASD_Dissociation']), *min_max_values['ASD_Dissociation'])
    ASD_Reexperience = normalize(float(request.form['ASD_Reexperience']), *min_max_values['ASD_Reexperience'])
    ASD_Avoidance = normalize(float(request.form['ASD_Avoidance']), *min_max_values['ASD_Avoidance'])
    ASD_Hypervigilance = normalize(float(request.form['ASD_Hypervigilance']), *min_max_values['ASD_Hypervigilance'])
    resilience = normalize(float(request.form['resilience']), *min_max_values['resilience'])
    hometown = request.form['hometown']
    income = request.form['income']
    
    # 处理上传的脑电波文件
    if 'eegFile' not in request.files:
        return "No file part", 400
    file = request.files['eegFile']
    if file.filename == '':
        return "No selected file", 400
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        eeg_data = pd.read_csv(file_path)
        
        # 检查必须的列
        required_columns = ['focus', 'relaxion', 'alpha1', 'alpha2', 'beta1', 'beta2', 'gamma1', 'gamma2']
        if not all(column in eeg_data.columns for column in required_columns):
            return "Missing required columns in EEG data", 400
        
        # 计算特征
        features = extract_features(eeg_data)
        
        # 加载模型并进行预测
        model_path = 'models/best_rf_model.pkl'
        model = load(model_path)
        input_features = [ASD_Dissociation, ASD_Reexperience, ASD_Avoidance, ASD_Hypervigilance, resilience] + features
        prediction = model.predict([input_features])
        
        return jsonify({'prediction': prediction.tolist()})
    return "Something went wrong", 400

def extract_features(data):
    # 计算alpha1和alpha2的对数不对称性
    wave_asymmetry = np.log(data['alpha1'] + 1) - np.log(data['alpha2'] + 1)
    
    # 计算Beta1和Gamma1的相关性
    functional_connectivity_1 = data['beta1'].corr(data['gamma1'])
    
    # 计算Beta2和Gamma2的相关性
    functional_connectivity_2 = data['beta2'].corr(data['gamma2'])
    
    # 计算特征
    columns = ['focus', 'relaxion', 'alpha1', 'alpha2']
    stats = ['mean', 'std', 'max', 'min', 'Skewness', 'Kurtosis', 'Peak-to-Peak', 'RMS', 'Amplitude_Factor', 'Form_Factor', 'Impact_Factor', 'Margin_Factor', 'Energy']
    feature_list = []

    for column in columns:
        series = data[column]
        feature_list.extend([
            series.mean(), 
            series.std(), 
            series.max(), 
            series.min(), 
            skew(series),
            kurtosis(series),
            series.max() - series.min(), 
            np.sqrt(np.mean(series**2)), 
            (series.max() - series.min()) / np.sqrt(np.mean(series**2)),
            np.sqrt(np.mean(series**2)) / np.mean(np.abs(series)),
            (series.max() - np.mean(series)) / np.sqrt(np.mean(series**2)),
            series.max() / np.sqrt(np.mean(series**2)),
            np.sum(series**2)
        ])
    
    feature_list.extend([functional_connectivity_1, functional_connectivity_2, wave_asymmetry.mean()])
    return feature_list

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)
