document.getElementById('questionnaireForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // 获取表单数据
    const disaster = document.getElementById('disaster').value;
    const ASD_Dissociation = document.getElementById('ASD_Dissociation').value;
    const ASD_Reexperience = document.getElementById('ASD_Reexperience').value;
    const ASD_Avoidance = document.getElementById('ASD_Avoidance').value;
    const ASD_Hypervigilance = document.getElementById('ASD_Hypervigilance').value;
    const resilience = document.getElementById('resilience').value;
    const hometown = document.getElementById('hometown').value;
    const income = document.getElementById('income').value;
    const eegFile = document.getElementById('eegFile').files[0];

    // 显示选定的数据
    document.getElementById('disasterValue').innerText = disaster;
    document.getElementById('ASD_DissociationValue').innerText = ASD_Dissociation;
    document.getElementById('ASD_ReexperienceValue').innerText = ASD_Reexperience;
    document.getElementById('ASD_AvoidanceValue').innerText = ASD_Avoidance;
    document.getElementById('ASD_HypervigilanceValue').innerText = ASD_Hypervigilance;
    document.getElementById('resilienceValue').innerText = resilience;
    document.getElementById('hometownValue').innerText = hometown;
    document.getElementById('incomeValue').innerText = income;
    document.getElementById('eegFileName').innerText = eegFile ? eegFile.name : '未上传文件';

    // 创建FormData对象
    const formData = new FormData();
    formData.append('disaster', disaster);
    formData.append('ASD_Dissociation', ASD_Dissociation);
    formData.append('ASD_Reexperience', ASD_Reexperience);
    formData.append('ASD_Avoidance', ASD_Avoidance);
    formData.append('ASD_Hypervigilance', ASD_Hypervigilance);
    formData.append('resilience', resilience);
    formData.append('hometown', hometown);
    formData.append('income', income);
    formData.append('eegFile', eegFile);

    // 提交表单数据到服务器
    fetch('/submit', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});
