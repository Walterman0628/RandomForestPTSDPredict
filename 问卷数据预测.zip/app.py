from flask import Flask, request, jsonify, send_from_directory
import numpy as np
import os

app = Flask(__name__)

# 假设以下是连续变量的最小值和最大值
min_max_values = {
    'age': (0, 100),
    'ASD_Dissociation': (5, 25),
    'ASD_Reexperience': (5, 25),
    'ASD_Aviodance': (4, 20),
    'ASD_Hypervigilance': (5, 25),
    'resilience': (10, 50)
}

def min_max_normalize(value, min_value, max_value):
    return (value - min_value) / (max_value - min_value)

def predict_ptsd(age, gender, minority, accident, memberaccident, injurywitness, corpse, disaster, mentalillness, medicine, drinker, ASD_Dissociation, ASD_Reexperiencing, ASD_Aviodance, ASD_Hypervigilance, history, resilience, hometown, culture, income, smoking):
    intercept = -0.311
    coefficients = np.array([0.013, 0.046, -0.023, -0.011, -0.009, -0.011, 0.044, 0.199, 0.062, 0.061, 0.098, 0.160, 0.182, 0.171, 0.203, 0.062, -0.128, -0.009, 0.100, -0.067, 0.052, -0.032, -0.031, 0.050, -0.005, -0.056, -0.021, -0.036, -0.060, 0.106, -0.090, 0.074])
    features = np.array([age, gender, minority, accident, memberaccident, injurywitness, corpse, disaster, mentalillness, medicine, drinker, ASD_Dissociation, ASD_Reexperiencing, ASD_Aviodance, ASD_Hypervigilance, history, resilience, hometown == 1, hometown == 2, hometown == 3, hometown == 5, hometown == 6, hometown == 7, culture == 1, culture == 2, culture == 3, income == 1, income == 2, income == 3, income == 4, smoking == 1, smoking == 2])
    
    logit = intercept + np.dot(features, coefficients)
    odds = np.exp(logit)
    probability = odds / (1 + odds)
    
    return probability

@app.route('/')
def index():
    return send_from_directory(os.getcwd(), 'index.html')

@app.route('/submit', methods=['POST'])
def submit():
    data = request.get_json()
    
    # 进行归一化处理
    age = min_max_normalize(int(data['age']), *min_max_values['age'])
    ASD_Dissociation = min_max_normalize(int(data['ASD_Dissociation']), *min_max_values['ASD_Dissociation'])
    ASD_Reexperiencing = min_max_normalize(int(data['ASD_Reexperience']), *min_max_values['ASD_Reexperience'])
    ASD_Aviodance = min_max_normalize(int(data['ASD_Avoidance']), *min_max_values['ASD_Aviodance'])
    ASD_Hypervigilance = min_max_normalize(int(data['ASD_Hypervigilance']), *min_max_values['ASD_Hypervigilance'])
    resilience = min_max_normalize(int(data['resilience']), *min_max_values['resilience'])
    
    input_data = [
        age,
        int(data['gender']),
        int(data['minority']),
        int(data['accident']),
        int(data['memberaccident']),
        int(data['injurywitness']),
        int(data['corpse']),
        int(data['disaster']),
        int(data['mentalillness']),
        int(data['medicine']),
        int(data['drinker']),
        ASD_Dissociation,
        ASD_Reexperiencing,
        ASD_Aviodance,
        ASD_Hypervigilance,
        int(data['history']),
        resilience,
        int(data['hometown']),
        int(data['culture']),
        int(data['income']),
        int(data['smoking'])
    ]
    
    probability = predict_ptsd(*input_data)
    return jsonify({'probability': probability})

if __name__ == '__main__':
    app.run(debug=True)
