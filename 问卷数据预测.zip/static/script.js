// static/script.js
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        // Perform custom form validation if needed
        const age = document.getElementById('age').value;
        if (age < 18 || age > 99) {
            alert('Age must be between 18 and 99.');
            event.preventDefault();  // Prevent form submission
        }
    });
});
